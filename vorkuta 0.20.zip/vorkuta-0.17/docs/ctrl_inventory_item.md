# `CtrlInventoryItem`

Inherits: `CtrlInventoryItemBase`

## Description

Control node for displaying inventory items.

Displays an `InventoryItem` icon and its stack size. Consists of a `TextureRect` (the icon) a `Label` (the stack size).

